const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('lotissementAPI', Object.freeze({
  saveGuCase: (guCase) => ipcRenderer.invoke('gu:save', guCase),
  loadGuCase: (reference) => ipcRenderer.invoke('gu:load', reference),
  searchGuCases: (query) => ipcRenderer.invoke('gu:search', query),
  listGuCases: () => ipcRenderer.invoke('gu:list'),
  deleteGuCase: (id) => ipcRenderer.invoke('gu:delete', id),
  listAvailableGuCases: (recCaseId) => ipcRenderer.invoke('rec:list-available-gu', recCaseId),
  createRecCase: (recCase) => ipcRenderer.invoke('rec:create', recCase),
  listRecCases: () => ipcRenderer.invoke('rec:list'),
  loadRecCase: (id) => ipcRenderer.invoke('rec:load', id),
  updateRecCase: (recCase) => ipcRenderer.invoke('rec:update', recCase),
  listComparisons: () => ipcRenderer.invoke('comparison:list'),
  loadComparison: (id) => ipcRenderer.invoke('comparison:load', id),
  saveComparison: (comparison) => ipcRenderer.invoke('comparison:save', comparison),
  loadButtonPreferences: () => ipcRenderer.invoke('preferences:buttons:load'),
  saveButtonPreferences: (preferences) =>
    ipcRenderer.invoke('preferences:buttons:save', preferences)
}));