
const { app, BrowserWindow, ipcMain } = require('electron');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { fileURLToPath } = require('node:url');
const {
  initializeDatabase,
  createRecCase,
  deleteGuCase,
  listRecCases,
  listAvailableGuCases,
  listGuCases,
  loadGuCase,
  loadRecCase,
  saveGuCase,
  searchGuCases,
  updateRecCase,
  listComparisons,
  loadComparison,
  saveComparison
} = require('./database');

const defaultUserDataPath = path.join(__dirname, 'data', 'rec-dev');
const testMode = process.env.REC_TEST_MODE;

function createTestUserDataPath() {
  const temporaryRoot = fs.realpathSync(os.tmpdir());
  const userDataPath = fs.mkdtempSync(
    path.join(temporaryRoot, 'monpremierelectron-rec-test-')
  );
  const directoryStats = fs.lstatSync(userDataPath);
  const realUserDataPath = fs.realpathSync(userDataPath);
  const relativeDirectory = path.relative(temporaryRoot, realUserDataPath);

  if (!directoryStats.isDirectory() || directoryStats.isSymbolicLink() ||
      path.resolve(userDataPath) !== realUserDataPath ||
      relativeDirectory === '..' ||
      relativeDirectory.startsWith(`..${path.sep}`) ||
      path.isAbsolute(relativeDirectory)) {
    throw new Error('Le répertoire temporaire REC ne peut pas être validé.');
  }

  const databasePath = path.join(realUserDataPath, 'lotissement.sqlite');
  for (const filePath of [
    databasePath,
    `${databasePath}-journal`,
    `${databasePath}-wal`,
    `${databasePath}-shm`
  ]) {
    try {
      fs.lstatSync(filePath);
      throw new Error('Un fichier de base existe déjà dans le répertoire temporaire REC.');
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }
  }

  return realUserDataPath;
}

if (testMode !== undefined && testMode !== '1') {
  throw new Error('REC_TEST_MODE doit être défini à 1 ou ne pas être défini.');
}

const testUserDataPath = testMode === '1' ? createTestUserDataPath() : null;

app.setPath(
  'userData',
  testUserDataPath || defaultUserDataPath
);

let database;
let mainWindow;

const categoryCodes = new Set([
  'voirie',
  'eau-potable',
  'assainissement',
  'electricite',
  'telecommunications',
  'eclairage-public',
  'espaces-publics',
  'autre'
]);

function requireText(value, field, maxLength) {
  if (typeof value !== 'string') {
    throw new Error(`${field} doit être un texte.`);
  }

  const normalized = value.trim();
  if (!normalized || normalized.length > maxLength) {
    throw new Error(`${field} est obligatoire et limité à ${maxLength} caractères.`);
  }

  return normalized;
}

function validateReference(value) {
  return requireText(value, 'La référence GU', 100);
}

function optionalText(value, field, maxLength) {
  if (value === undefined || value === null) return null;
  if (typeof value !== 'string') {
    throw new Error(`${field} doit être un texte.`);
  }

  const normalized = value.trim();
  if (normalized.length > maxLength) {
    throw new Error(`${field} est limité à ${maxLength} caractères.`);
  }

  return normalized || null;
}

function validateGuCaseId(value) {
  if (!Number.isSafeInteger(value) || value <= 0) {
    throw new Error('L’identifiant du dossier GU est invalide.');
  }
  return value;
}

function validateRecCase(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('بيانات ملف التكلفة الحقيقية غير صالحة.');
  }

  if (typeof value.reference !== 'string' || !value.reference.trim() ||
      value.reference.trim().length > 100) {
    throw new Error('مرجع ملف التكلفة الحقيقية مطلوب، ويجب ألا يتجاوز 100 حرف.');
  }

  const reference = value.reference.trim();
  return {
    reference,
    lotName: requireText(value.lotName, 'اسم التجزئة', 200),
    guCaseId: value.guCaseId == null ? null : validateGuCaseId(value.guCaseId),
    invoices: validateRecInvoices(value.invoices)
  };
}

function validateRecCaseId(value) {
  if (!Number.isSafeInteger(value) || value <= 0) {
    throw new Error('معرّف ملف التكلفة الحقيقية غير صالح.');
  }
  return value;
}

function validateComparison(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('بيانات المقارنة غير صالحة.');
  }
  if (!Array.isArray(value.invoices) || value.invoices.length > 2000) {
    throw new Error('قائمة فواتير المقارنة غير صالحة.');
  }

  const id = value.id == null ? null : validateComparisonId(value.id);
  const sourceRecCaseId = value.sourceRecCaseId == null
    ? null
    : validateRecCaseId(value.sourceRecCaseId);
  const invoices = value.invoices.map((invoice) => {
    if (!invoice || typeof invoice !== 'object' || Array.isArray(invoice)) {
      throw new Error('بيانات إحدى فواتير المقارنة غير صالحة.');
    }
    if (!categoryCodes.has(invoice.categoryCode)) {
      throw new Error('فئة إحدى فواتير المقارنة غير صالحة.');
    }
    if (!Number.isSafeInteger(invoice.amountMinor) || invoice.amountMinor < 0) {
      throw new Error('مبلغ إحدى فواتير المقارنة غير صالح.');
    }
    return {
      categoryCode: invoice.categoryCode,
      description: typeof invoice.description === 'string'
        ? invoice.description.trim().slice(0, 500)
        : '',
      amountMinor: invoice.amountMinor
    };
  });

  return {
    id,
    name: requireText(value.name, 'Le nom de la comparaison', 200),
    sourceRecCaseId,
    invoices
  };
}

function validateComparisonId(value) {
  if (!Number.isSafeInteger(value) || value <= 0) {
    throw new Error('معرّف المقارنة غير صالح.');
  }
  return value;
}

function validateRecInvoices(value) {
  if (!Array.isArray(value) || value.length > 2000) {
    throw new Error('قائمة فواتير التكلفة الحقيقية غير صالحة.');
  }

  return value.map((invoice) => {
    if (!invoice || typeof invoice !== 'object' || Array.isArray(invoice)) {
      throw new Error('بيانات إحدى الفواتير غير صالحة.');
    }
    if (!categoryCodes.has(invoice.categoryCode)) {
      throw new Error('فئة إحدى الفواتير غير صالحة.');
    }
    if (!Number.isSafeInteger(invoice.amountMinor) || invoice.amountMinor < 0) {
      throw new Error('يجب إدخال مبلغ الفاتورة بالسنتيم.');
    }

    return {
      categoryCode: invoice.categoryCode,
      description: typeof invoice.description === 'string'
        ? invoice.description.trim().slice(0, 500)
        : '',
      amountMinor: invoice.amountMinor
    };
  });
}

function validateGuCase(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('Les données du dossier sont invalides.');
  }

  if (!Array.isArray(value.invoices) || value.invoices.length > 2000) {
    throw new Error('La liste des factures est invalide.');
  }

  const id = value.id ?? null;
  if (id !== null && (!Number.isSafeInteger(id) || id <= 0)) {
    throw new Error('L’identifiant du dossier GU est invalide.');
  }

  for (const rate of [value.taxRatePercent, value.advanceRatePercent]) {
    if (typeof rate !== 'number' || !Number.isFinite(rate) || rate < 0) {
      throw new Error('Les taux doivent être des nombres positifs ou nuls.');
    }
  }

  const invoices = value.invoices.map((invoice) => {
    if (!invoice || typeof invoice !== 'object' || Array.isArray(invoice)) {
      throw new Error('Une facture est invalide.');
    }
    if (!categoryCodes.has(invoice.categoryCode)) {
      throw new Error('Une catégorie de facture est invalide.');
    }
    if (!Number.isSafeInteger(invoice.amountMinor) || invoice.amountMinor < 0) {
      throw new Error('Le montant d’une facture doit être en centimes.');
    }

    return {
      categoryCode: invoice.categoryCode,
      description: typeof invoice.description === 'string'
        ? invoice.description.trim().slice(0, 500)
        : '',
      amountMinor: invoice.amountMinor
    };
  });

  return {
    id,
    reference: optionalText(value.reference, 'La référence GU', 100),
    companyName: optionalText(value.companyName, 'Le nom du projet', 200),
    taxRatePercent: value.taxRatePercent,
    advanceRatePercent: value.advanceRatePercent,
    invoices
  };
}

function assertTrustedRenderer(event) {
  if (!mainWindow || event.sender !== mainWindow.webContents ||
      event.senderFrame !== mainWindow.webContents.mainFrame) {
    throw new Error('Origine de la requête IPC refusée.');
  }

  try {
    const senderPath = fileURLToPath(event.senderFrame.url);
    const expectedPath = path.resolve(__dirname, 'previsionnel', 'index.html');
    if (path.resolve(senderPath).toLowerCase() !== expectedPath.toLowerCase()) {
      throw new Error('Origine de la requête IPC refusée.');
    }
  } catch {
    throw new Error('Origine de la requête IPC refusée.');
  }
}

ipcMain.handle('gu:save', (event, value) => {
  assertTrustedRenderer(event);
  return saveGuCase(database, validateGuCase(value));
});

ipcMain.handle('gu:load', (event, id) => {
  assertTrustedRenderer(event);
  return loadGuCase(database, validateGuCaseId(id));
});

ipcMain.handle('gu:search', (event, query) => {
  assertTrustedRenderer(event);
  return searchGuCases(database, requireText(query, 'La recherche GU', 100));
});

ipcMain.handle('gu:list', (event) => {
  assertTrustedRenderer(event);
  return listGuCases(database);
});

ipcMain.handle('gu:delete', (event, id) => {
  assertTrustedRenderer(event);
  return deleteGuCase(database, validateGuCaseId(id));
});

ipcMain.handle('rec:list-available-gu', (event, recCaseId) => {
  assertTrustedRenderer(event);
  const currentRecCaseId = recCaseId == null
    ? null
    : validateRecCaseId(recCaseId);
  return listAvailableGuCases(database, currentRecCaseId);
});

ipcMain.handle('rec:create', (event, value) => {
  assertTrustedRenderer(event);
  return createRecCase(database, validateRecCase(value));
});

ipcMain.handle('rec:list', (event) => {
  assertTrustedRenderer(event);
  return listRecCases(database);
});

ipcMain.handle('rec:load', (event, id) => {
  assertTrustedRenderer(event);
  return loadRecCase(database, validateRecCaseId(id));
});

ipcMain.handle('rec:update', (event, value) => {
  assertTrustedRenderer(event);
  const id = validateRecCaseId(value?.id);
  return updateRecCase(database, { ...validateRecCase(value), id });
});

ipcMain.handle('comparison:list', (event) => {
  assertTrustedRenderer(event);
  return listComparisons(database);
});

ipcMain.handle('comparison:load', (event, id) => {
  assertTrustedRenderer(event);
  return loadComparison(database, validateComparisonId(id));
});

ipcMain.handle('comparison:save', (event, value) => {
  assertTrustedRenderer(event);
  return saveComparison(database, validateComparison(value));
});

function validateButtonPreferences(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('Les préférences des boutons sont invalides.');
  }

  const preferences = {};
  const entries = Object.entries(value);
  if (entries.length > 200) {
    throw new Error('Le nombre de préférences des boutons est invalide.');
  }

  for (const [key, preference] of entries) {
    if (!/^[a-zA-Z0-9._-]{1,100}$/.test(key) ||
        !preference || typeof preference !== 'object' || Array.isArray(preference)) {
      throw new Error('Une préférence de bouton est invalide.');
    }

    const validated = {};
    if (preference.label !== undefined) {
      if (typeof preference.label !== 'string' ||
          !preference.label.trim() || preference.label.trim().length > 80) {
        throw new Error('Le libellé d’un bouton doit contenir de 1 à 80 caractères.');
      }
      validated.label = preference.label.trim();
    }

    for (const colorKey of ['backgroundColor', 'textColor']) {
      if (preference[colorKey] !== undefined) {
        if (typeof preference[colorKey] !== 'string' ||
            !/^#[0-9a-fA-F]{6}$/.test(preference[colorKey])) {
          throw new Error('Une couleur de bouton est invalide.');
        }
        validated[colorKey] = preference[colorKey].toLowerCase();
      }
    }

    if (Object.keys(validated).length) preferences[key] = validated;
  }

  return preferences;
}

ipcMain.handle('preferences:buttons:load', (event) => {
  assertTrustedRenderer(event);
  const preferencesPath = path.join(app.getPath('userData'), 'button-preferences.json');
  try {
    return validateButtonPreferences(JSON.parse(fs.readFileSync(preferencesPath, 'utf8')));
  } catch (error) {
    if (error.code === 'ENOENT') return {};
    throw error;
  }
});

ipcMain.handle('preferences:buttons:save', (event, value) => {
  assertTrustedRenderer(event);
  const preferences = validateButtonPreferences(value);
  const preferencesPath = path.join(app.getPath('userData'), 'button-preferences.json');
  const temporaryPath = `${preferencesPath}.${process.pid}.tmp`;
  fs.writeFileSync(temporaryPath, `${JSON.stringify(preferences, null, 2)}\n`, {
    encoding: 'utf8',
    flag: 'w'
  });
  fs.renameSync(temporaryPath, preferencesPath);
  return preferences;
});

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1000,
    height: 700,
    title: 'تدبير رسوم التجزئات العقارية',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  mainWindow.loadFile('previsionnel/index.html');

  if (process.env.ELECTRON_OPEN_DEVTOOLS === '1') {
    mainWindow.webContents.openDevTools();
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(async () => {
  const databasePath = path.join(app.getPath('userData'), 'lotissement.sqlite');
  database = await initializeDatabase(databasePath);
  createWindow();
}).catch((error) => {
  console.error('Impossible d’initialiser la base de données locale.', error);
  app.quit();
});

app.on('before-quit', () => {
  if (database?.isOpen) database.close();
});
